4/5/12

We are fixing the syllabifications:  s + stop may be able to begin a word, but V s stop V is divided V s . stop V.

